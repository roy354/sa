<?php
class bot {
	var $ticket;
	var $meid;
	var $sign;
	var $jenis;
	function kode($panjang, $jenis) {
		switch ($jenis) {
		case '1':
			$str = array_merge(range("0", "9"));
			break;
		case '2':
			$str = array_merge(range("0", "9"), range("a", "z"));
			break;
		case '3':
			$str = array_merge(range("0", "9"), range("a", "z"), range("A", "Z"));
			break;
		default:
			$str = array_merge(range("0", "9"), range("a", "z"));
			break;
		}
		$kode = "";
		for ($i = 0; $i < $panjang; $i++) {
			$kode .= $str[array_rand($str)];
		}
		return $kode;
	}
	function __construct() {
		$this->ticket = null; // Sangat penting jadi null saja
		$this->meid = $this->kode(16, 3);
		$this->sign = $this->kode(118, 3);
		$data = file_get_contents("hp.txt");
		$data = explode(",", $data);
		$this->hp = $data[array_rand($data)];
		$this->kode_ref = file_get_contents("kode_ref.txt"); // Kode referal
		$data1 = file_get_contents("nama.txt");
		$data1 = explode(",", $data1);
		$this->nama = $data1[array_rand($data1)] . $data1[array_rand($data1)];
		$data1 = file_get_contents("ico.txt");
		$data1 = explode("\n", $data1);
		$this->ico = $data1[array_rand($data1)];
	}
	function login() {
		$meid = $this->meid;
		$nama = $this->nama;
		$sign = $this->sign;
		$hp = $this->hp;
		$ico = $this->ico;
		$kode_ref = $this->kode_ref;
		switch ($jenis) {
		// rupa json
		case 'fb':
			$data = "source_login=fb&fb_id=anjing";
			break;
		case 'gmail':
			$data = "source_login=gmail&gm_id=blabla";
			break;
		default:
			$data = "source_login=fb&fb_id=ddnsds";
			break;
		}
		// Proses login

		// akhir Login
		if ($kode_ref == 0) {
			$this->tambah_ref();
		}
		// set ticket
		$this->ticket = "nama";
	}
	function lihat() {

		$meid = $this->meid;
		$sign = $this->sign;
		$ticket = $this->ticket;
		$hp = $this->hp;

		//lihat video//
	}
	function tambah_ref() {
		$meid = $this->meid;
		$sign = $this->sign;
		$ticket = $this->ticket;
		$hp = $this->hp;

		// proses tambah reff
	}
}
$nama = new bot();
?>